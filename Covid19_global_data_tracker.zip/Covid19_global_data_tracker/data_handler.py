import requests
import pandas as pd

API_URL = "https://disease.sh/v3/covid-19"
HISTORY_API = "https://disease.sh/v3/covid-19/historical"

def fetch_global_data():
    return requests.get(f"{API_URL}/all").json()

def fetch_country_data():
    return pd.DataFrame(requests.get(f"{API_URL}/countries").json())

def fetch_country_history(country):
    url = f"{HISTORY_API}/{country}?lastdays=30"
    res = requests.get(url)
    if res.status_code != 200:
        return None
    return res.json()
