import tkinter as tk
from gui import CovidTrackerApp

if __name__ == "__main__":
    root = tk.Tk()
    app = CovidTrackerApp(root)
    root.mainloop()
