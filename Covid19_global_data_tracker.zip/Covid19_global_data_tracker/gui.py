import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from data_handler import fetch_country_data, fetch_country_history, fetch_global_data
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class CovidTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("COVID-19 Global Tracker")
        self.root.geometry("800x700")
        
        self.country_data = fetch_country_data()
        self.create_widgets()

        # ✅ Footer with version and author
        footer = ttk.Label(self.root, text="Version 1.0 | Developed by Charles Mori", font=("Arial", 9), foreground="gray")
        footer.pack(side="bottom", pady=5)

    def create_widgets(self):
        # Global Summary
        global_data = fetch_global_data()
        frame_summary = ttk.LabelFrame(self.root, text="🌍 Global Summary")
        frame_summary.pack(fill="x", padx=10, pady=5)

        ttk.Label(frame_summary, text=f"Cases: {global_data['cases']:,}").pack(side="left", padx=20)
        ttk.Label(frame_summary, text=f"Deaths: {global_data['deaths']:,}").pack(side="left", padx=20)
        ttk.Label(frame_summary, text=f"Recovered: {global_data['recovered']:,}").pack(side="left", padx=20)

        # Country Search
        frame_search = ttk.LabelFrame(self.root, text="🔍 Country Search")
        frame_search.pack(fill="x", padx=10, pady=5)

        self.country_entry = ttk.Entry(frame_search, width=30)
        self.country_entry.pack(side="left", padx=10)
        ttk.Button(frame_search, text="Search", command=self.search_country).pack(side="left")

        self.result_label = ttk.Label(self.root, text="", font=("Helvetica", 12))
        self.result_label.pack(pady=5)

        # Top 10 Countries Chart
        frame_chart = ttk.LabelFrame(self.root, text="📊 Top 10 Affected Countries")
        frame_chart.pack(fill="both", expand=True, padx=10, pady=5)

        self.plot_top_countries(frame_chart)

        # Historical Chart Frame
        self.history_frame = ttk.LabelFrame(self.root, text="📈 Country Historical (Last 30 Days)")
        self.history_frame.pack(fill="both", expand=True, padx=10, pady=5)

    def plot_top_countries(self, frame):
        top = self.country_data.sort_values(by="cases", ascending=False).head(10)
        countries = top['country']
        cases = top['cases']

        fig, ax = plt.subplots(figsize=(7, 4))
        ax.barh(countries[::-1], cases[::-1], color='coral')
        ax.set_xlabel("Cases")
        ax.set_title("Top 10 Countries by Total Cases")

        canvas = FigureCanvasTkAgg(fig, master=frame)
        canvas.draw()
        canvas.get_tk_widget().pack()

    def search_country(self):
        name = self.country_entry.get().strip().lower()
        match = self.country_data[self.country_data['country'].str.lower() == name]
        for widget in self.history_frame.winfo_children():
            widget.destroy()

        if match.empty:
            self.result_label.config(text=f"❌ Country '{name}' not found.", foreground="red")
            return

        country = match.iloc[0]
        self.result_label.config(
            text=(
                f"{country['country']} - Cases: {country['cases']:,} | "
                f"Deaths: {country['deaths']:,} | Recovered: {country['recovered']:,}"
            ),
            foreground="black"
        )

        history = fetch_country_history(country['country'])
        if history and 'timeline' in history:
            self.plot_history(history['timeline'])
        else:
            ttk.Label(self.history_frame, text="No historical data available.").pack()

    def plot_history(self, timeline):
        dates = list(timeline['cases'].keys())
        cases = list(timeline['cases'].values())
        deaths = list(timeline['deaths'].values())

        fig, ax = plt.subplots(figsize=(7, 4))
        ax.plot(dates, cases, label='Cases', marker='o')
        ax.plot(dates, deaths, label='Deaths', marker='x')
        ax.set_title("Last 30 Days Trend")
        ax.set_xticks(dates[::5])
        ax.set_xticklabels(dates[::5], rotation=45)
        ax.legend()
        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.history_frame)
        canvas.draw()
        canvas.get_tk_widget().pack()
